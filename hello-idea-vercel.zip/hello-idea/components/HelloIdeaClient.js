'use client';

import { useState } from 'react';

const panelStyle = {
  background: '#ffffff',
  border: '1px solid rgba(0,0,0,0.08)',
  borderRadius: 24,
  padding: 20,
  boxShadow: '0 6px 20px rgba(0,0,0,0.04)',
};

const textareaStyle = {
  width: '100%',
  minHeight: 260,
  resize: 'vertical',
  borderRadius: 18,
  border: '1px solid rgba(0,0,0,0.1)',
  background: '#fcfaf6',
  padding: 16,
  outline: 'none',
};

const buttonStyle = {
  border: 'none',
  borderRadius: 999,
  padding: '10px 18px',
  background: '#171717',
  color: '#fff',
  cursor: 'pointer',
  fontWeight: 600,
};

const promptIdeas = [
  'What is the smallest next step you can do in the next 24 hours?',
  'What part of this idea matters most to the person it is for?',
  'What have you assumed that may not actually need to be true?',
  'If you had to test this with almost no money, what would you do first?',
  'What is the problem inside the idea that needs solving next?'
];

export default function HelloIdeaClient() {
  const [idea, setIdea] = useState('');
  const [change, setChange] = useState('');
  const [stuck, setStuck] = useState('');
  const [yourIdea, setYourIdea] = useState('Your clarified idea will appear here.');
  const [yourPurpose, setYourPurpose] = useState('Your purpose will appear here.');
  const [nextPrompt, setNextPrompt] = useState('Your next question or prompt will appear here.');
  const [perspective, setPerspective] = useState('Fresh perspective will appear here when you get stuck.');
  const [loadingIdea, setLoadingIdea] = useState(false);
  const [loadingPerspective, setLoadingPerspective] = useState(false);
  const [error, setError] = useState('');

  async function handleIdeaSubmit() {
    setLoadingIdea(true);
    setError('');

    try {
      const response = await fetch('/api/idea', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'idea', idea, change }),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Something went wrong');

      setYourIdea(data.yourIdea);
      setYourPurpose(data.yourPurpose);
      setNextPrompt(data.nextPrompt || promptIdeas[Math.floor(Math.random() * promptIdeas.length)]);
    } catch (err) {
      setError(err.message || 'Something went wrong');
    } finally {
      setLoadingIdea(false);
    }
  }

  async function handlePerspectiveSubmit() {
    setLoadingPerspective(true);
    setError('');

    try {
      const response = await fetch('/api/idea', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'perspective', idea: yourIdea, purpose: yourPurpose, stuck }),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Something went wrong');

      setPerspective(data.perspective);
      setNextPrompt(data.nextPrompt || nextPrompt);
    } catch (err) {
      setError(err.message || 'Something went wrong');
    } finally {
      setLoadingPerspective(false);
    }
  }

  return (
    <main style={{ minHeight: '100vh', padding: '32px 20px' }}>
      <div style={{ maxWidth: 1180, margin: '0 auto' }}>
        <div style={{ marginBottom: 28 }}>
          <p style={{ margin: 0, letterSpacing: '0.18em', textTransform: 'uppercase', fontSize: 12, opacity: 0.55 }}>hello idea</p>
          <h1 style={{ margin: '10px 0 12px', fontSize: 'clamp(36px, 6vw, 68px)', lineHeight: 1, maxWidth: 860 }}>Get your idea out of your head.</h1>
          <p style={{ margin: 0, maxWidth: 760, fontSize: 18, lineHeight: 1.6, opacity: 0.7 }}>
            Write it messy. We’ll help make it clearer, surface the purpose, and give you a fresh perspective when you get stuck.
          </p>
        </div>

        <div style={{ display: 'grid', gap: 20, gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))' }}>
          <section style={panelStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'center', marginBottom: 14 }}>
              <h2 style={{ margin: 0, fontSize: 24 }}>Your idea</h2>
              <button style={buttonStyle} onClick={handleIdeaSubmit} disabled={loadingIdea}>{loadingIdea ? 'Working...' : 'Go'}</button>
            </div>
            <textarea style={textareaStyle} value={idea} onChange={(e) => setIdea(e.target.value)} placeholder="Write here. Messy is fine. Tip: include who it’s for and why it helps." />
          </section>

          <section style={panelStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'center', marginBottom: 14 }}>
              <h2 style={{ margin: 0, fontSize: 24 }}>Want to change or add anything?</h2>
              <button style={buttonStyle} onClick={handleIdeaSubmit} disabled={loadingIdea}>{loadingIdea ? 'Working...' : 'Go'}</button>
            </div>
            <textarea style={textareaStyle} value={change} onChange={(e) => setChange(e.target.value)} placeholder="I forgot to mention..." />
          </section>

          <section style={panelStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'center', marginBottom: 14 }}>
              <h2 style={{ margin: 0, fontSize: 24 }}>Stuck? Get new perspective</h2>
              <button style={buttonStyle} onClick={handlePerspectiveSubmit} disabled={loadingPerspective}>{loadingPerspective ? 'Working...' : 'Go'}</button>
            </div>
            <textarea style={textareaStyle} value={stuck} onChange={(e) => setStuck(e.target.value)} placeholder="Copy and paste the words from Your Idea and Your Purpose. Hit Go. Then add where you feel stuck." />
          </section>
        </div>

        {error ? (
          <div style={{ marginTop: 18, color: '#8a1f11', background: '#fff1ef', border: '1px solid #f3c6bf', borderRadius: 16, padding: 14 }}>
            {error}
          </div>
        ) : null}

        <div style={{ display: 'grid', gap: 20, gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', marginTop: 20 }}>
          <section style={panelStyle}>
            <p style={{ margin: 0, fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.18em', opacity: 0.5 }}>Output</p>
            <h3 style={{ margin: '10px 0 14px', fontSize: 26 }}>Your idea</h3>
            <div style={{ background: '#fcfaf6', borderRadius: 18, padding: 18, lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{yourIdea}</div>
          </section>

          <section style={panelStyle}>
            <p style={{ margin: 0, fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.18em', opacity: 0.5 }}>Output</p>
            <h3 style={{ margin: '10px 0 14px', fontSize: 26 }}>Your purpose</h3>
            <div style={{ background: '#fcfaf6', borderRadius: 18, padding: 18, lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{yourPurpose}</div>
          </section>

          <section style={{ ...panelStyle, gridColumn: '1 / -1' }}>
            <p style={{ margin: 0, fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.18em', opacity: 0.5 }}>Keep going</p>
            <h3 style={{ margin: '10px 0 14px', fontSize: 26 }}>Next prompt</h3>
            <div style={{ background: '#fcfaf6', borderRadius: 18, padding: 18, lineHeight: 1.7, whiteSpace: 'pre-wrap', marginBottom: 14 }}>{nextPrompt}</div>
            <h3 style={{ margin: '0 0 14px', fontSize: 26 }}>Fresh perspective</h3>
            <div style={{ background: '#fcfaf6', borderRadius: 18, padding: 18, lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{perspective}</div>
          </section>
        </div>

        <div style={{ ...panelStyle, marginTop: 20, lineHeight: 1.7, color: 'rgba(0,0,0,0.65)' }}>
          Keep it simple. Write down anything you like. Copy the words from Your Idea and Your Purpose into your notebook so you’ve got them when you need them.
        </div>
      </div>
    </main>
  );
}
